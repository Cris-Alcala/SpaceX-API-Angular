import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: '../assets/css-reset.css'
})
export class AppComponent {
  title = 'SpaceX';
}
